//
//  CardDetailViewController.swift
//  CardList
//
//  Created by 박경춘 on 2023/03/20.
//

import UIKit
import Lottie

class CardDetailViewController: UIViewController{
    
    var promotionDetail: PromotionDetail?
    
    @IBOutlet var lottieView: LottieAnimationView!
    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var periodLabel: UILabel!
    @IBOutlet var conditionLabel: UILabel!
    @IBOutlet var benefitconditionLabel: UILabel!
    @IBOutlet var benefitdetailLabel: UILabel!
    @IBOutlet var benefitdateLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let animationView = LottieAnimationView(name: "money")
        lottieView.contentMode = .scaleAspectFit
        lottieView.addSubview(animationView)
        animationView.frame = lottieView.bounds
        animationView.loopMode = .loop
        animationView.play()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        guard let detail = promotionDetail else { return }
        
        titleLabel.text = """
        \(detail.companyName)카드 쓰면
        \(detail.amount)만원 드려요
        """
        
        periodLabel.text = detail.period
        conditionLabel.text = detail.condition
        benefitconditionLabel.text = detail.benefitCondition
        benefitdetailLabel.text = detail.benefitDetail
        benefitdateLabel.text = detail.benefitDate
        
        
    }
    
}
