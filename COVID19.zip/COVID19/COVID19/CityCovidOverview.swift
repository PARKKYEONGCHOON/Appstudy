//
//  CityCovidOverview.swift
//  COVID19
//
//  Created by 박경춘 on 2023/03/17.
//

import Foundation

struct CityCovidOverview: Codable{
    let korea: CoividOverview
    let seoul: CoividOverview
    let busan: CoividOverview
    let daegu: CoividOverview
    let incheon: CoividOverview
    let gwangju: CoividOverview
    let daejeon: CoividOverview
    let ulsan: CoividOverview
    let sejong: CoividOverview
    let gyeonggi: CoividOverview
    let gangwon: CoividOverview
    let chungbuk: CoividOverview
    let chungnam: CoividOverview
    let jeonbuk: CoividOverview
    let jeonnam: CoividOverview
    let gyeongbuk: CoividOverview
    let gyeongnam: CoividOverview
    let jeju: CoividOverview
    
    
}

struct CoividOverview: Codable{
    
    let countryName: String
    let newCase: String
    let totalCase: String
    let recovered: String
    let death: String
    let percentage: String
    let newCcase: String
    let newFcase: String
    
    
}
