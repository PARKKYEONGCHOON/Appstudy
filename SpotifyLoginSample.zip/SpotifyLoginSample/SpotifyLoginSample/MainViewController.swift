//
//  MainViewController.swift
//  SpotifyLoginSample
//
//  Created by 박경춘 on 2023/03/19.
//

import UIKit
import FirebaseAuth

class MainViewController: UIViewController, UINavigationBarDelegate{
    
    @IBOutlet var welcomeLabel: UILabel!
    @IBOutlet var logoutButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.interactivePopGestureRecognizer?.isEnabled = false
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        navigationController?.navigationBar.isHidden = true
        
        let email = Auth.auth().currentUser?.email ?? "고객"
        
        welcomeLabel.text = """
        환영합니다.
        \(email)님
        """
    }
    
    @IBAction func logoutButton(_ sender: UIButton) {
        
        let firebaseAuth = Auth.auth()
        
        do {
            try firebaseAuth.signOut()
            self.navigationController?.popToRootViewController(animated: true)
        }
        
        catch let signOutError as NSError {
            print("\(signOutError.localizedDescription)")
        }
        
        
    }
}
