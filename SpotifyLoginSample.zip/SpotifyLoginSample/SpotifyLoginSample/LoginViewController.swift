//
//  LoginViewController.swift
//  SpotifyLoginSample
//
//  Created by 박경춘 on 2023/03/19.
//

import UIKit

class LoginViewController: UIViewController, UINavigationBarDelegate {
    
    @IBOutlet var emailLogInbutton: UIButton!
    @IBOutlet var googleLogInbutton: UIButton!
    @IBOutlet var appleLogInbutton: UIButton!
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        [emailLogInbutton, googleLogInbutton, appleLogInbutton].forEach {
            
            $0?.layer.borderWidth = 1
            $0?.layer.borderColor = UIColor.white.cgColor
            $0?.layer.cornerRadius = 30
            
        }
        
        
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        navigationController?.navigationBar.isHidden = true
        
    }
    
    @IBAction func emailLogin(_ sender: UIButton) {
    }
    
    @IBAction func googleLogin(_ sender: UIButton) {
    }
    
    @IBAction func appleLogin(_ sender: UIButton) {
    }
    
    
}
